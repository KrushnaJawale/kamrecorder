@echo off
cd /d "%~dp0"

set "PYTHON_EXE=%LocalAppData%\Programs\Python\Python314\python.exe"
if exist "%PYTHON_EXE%" (
    start "Flask App" cmd /k ""%PYTHON_EXE%" app.py"
) else (
    where py >nul 2>&1
    if %ERRORLEVEL% EQU 0 (
        start "Flask App" cmd /k "py -3 app.py"
    ) else (
        start "Flask App" cmd /k "python app.py"
    )
)

timeout /t 2 /nobreak >nul
start "" "http://127.0.0.1:5000/"
