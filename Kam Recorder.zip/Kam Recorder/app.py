import os
import shutil
import sqlite3
import subprocess
import sys
import json
import urllib.request
import urllib.error
from flask import Flask, render_template, request, jsonify, send_from_directory

app = Flask(__name__)

RECORDINGS_DIR = os.path.join(os.path.dirname(__file__), 'recordings')
DB_PATH = os.path.join(os.path.dirname(__file__), 'database.db')

if not os.path.exists(RECORDINGS_DIR):
    os.makedirs(RECORDINGS_DIR)

def get_db_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def get_next_groq_key_name(conn):
    rows = conn.execute('SELECT name FROM groq_keys').fetchall()
    used = set()
    for row in rows:
        name = str(row['name'] or '')
        if name.lower().startswith('groq '):
            suffix = name.split(' ', 1)[-1]
            if suffix.isdigit():
                used.add(int(suffix))

    n = 1
    while n in used:
        n += 1
    return f'Groq {n}'

def validate_database():
    if not os.path.exists(DB_PATH):
        open(DB_PATH, 'a').close()

    conn = get_db_connection()
    conn.execute('''
        CREATE TABLE IF NOT EXISTS recordings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            folder_name TEXT UNIQUE NOT NULL,
            mode TEXT NOT NULL,
            resolution TEXT NOT NULL,
            camera_file TEXT,
            screen_file TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    conn.execute('''
        CREATE TABLE IF NOT EXISTS groq_keys (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL,
            api_key TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    conn.commit()
    tables = [row['name'] for row in conn.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")]
    conn.close()
    return {
        'database_exists': os.path.exists(DB_PATH),
        'tables': tables,
        'database_path': DB_PATH,
    }

def init_db():
    return validate_database()

init_db()

# --- ROUTES ---

@app.route('/guide')
def guide():
    return send_from_directory(os.path.dirname(__file__), 'readme.html')

@app.route('/connect-groq')
def connect_groq():
    return render_template('groq.html')

@app.route('/creator')
def creator():
    return render_template('creator.html')

@app.route('/api/db-status', methods=['GET'])
def db_status():
    try:
        result = validate_database()
        return jsonify({'success': True, 'db': result})
    except Exception as exc:
        return jsonify({'success': False, 'error': str(exc)}), 500

@app.route('/')
def index():
    return render_template('index.html')

# 1. Validate Folder Name for Duplicates
@app.route('/api/validate-folder', methods=['POST'])
def validate_folder():
    data = request.get_json()
    folder_name = data.get('folder_name', '').strip()

    if not folder_name:
        return jsonify({'valid': False, 'message': 'Folder name cannot be empty.'})

    folder_path = os.path.join(RECORDINGS_DIR, folder_name)
    
    conn = get_db_connection()
    existing = conn.execute('SELECT id FROM recordings WHERE folder_name = ?', (folder_name,)).fetchone()
    conn.close()

    if os.path.exists(folder_path) or existing:
        return jsonify({'valid': False, 'message': 'Folder name already exists!'})

    return jsonify({'valid': True, 'message': 'Folder name available!'})

# 2. CREATE: Save Video Files & Insert into SQL DB
@app.route('/api/recordings', methods=['POST'])
def save_recording():
    folder_name = request.form.get('folder_name').strip()
    mode = request.form.get('mode')
    resolution = request.form.get('resolution')

    target_dir = os.path.join(RECORDINGS_DIR, folder_name)
    os.makedirs(target_dir, exist_ok=True)

    camera_path = None
    screen_path = None

    if 'camera' in request.files:
        cam_file = request.files['camera']
        cam_filename = f"camera.webm"
        cam_file.save(os.path.join(target_dir, cam_filename))
        camera_path = f"/recordings/{folder_name}/{cam_filename}"

    if 'screen' in request.files:
        screen_file = request.files['screen']
        scr_filename = f"screen.webm"
        screen_file.save(os.path.join(target_dir, scr_filename))
        screen_path = f"/recordings/{folder_name}/{scr_filename}"

    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO recordings (folder_name, mode, resolution, camera_file, screen_file)
        VALUES (?, ?, ?, ?, ?)
    ''', (folder_name, mode, resolution, camera_path, screen_path))
    conn.commit()
    new_id = cursor.lastrowid
    conn.close()

    return jsonify({'success': True, 'id': new_id, 'folder_name': folder_name})

# 3. READ: Get All Recordings from SQL
@app.route('/api/recordings', methods=['GET'])
def get_recordings():
    conn = get_db_connection()
    records = conn.execute('SELECT * FROM recordings ORDER BY created_at DESC').fetchall()
    conn.close()
    return jsonify([dict(row) for row in records])

# 4. UPDATE: Rename Folder in File System & SQL DB
@app.route('/api/recordings/<int:rec_id>', methods=['PUT'])
def update_recording(rec_id):
    data = request.get_json()
    new_name = data.get('folder_name', '').strip()

    conn = get_db_connection()
    record = conn.execute('SELECT * FROM recordings WHERE id = ?', (rec_id,)).fetchone()

    if not record:
        conn.close()
        return jsonify({'error': 'Record not found'}), 404

    old_name = record['folder_name']
    old_path = os.path.join(RECORDINGS_DIR, old_name)
    new_path = os.path.join(RECORDINGS_DIR, new_name)

    if os.path.exists(new_path):
        conn.close()
        return jsonify({'error': 'New folder name already exists'}), 400

    if os.path.exists(old_path):
        os.rename(old_path, new_path)

    new_cam_path = record['camera_file'].replace(f"/recordings/{old_name}/", f"/recordings/{new_name}/") if record['camera_file'] else None
    new_scr_path = record['screen_file'].replace(f"/recordings/{old_name}/", f"/recordings/{new_name}/") if record['screen_file'] else None

    conn.execute('''
        UPDATE recordings 
        SET folder_name = ?, camera_file = ?, screen_file = ? 
        WHERE id = ?
    ''', (new_name, new_cam_path, new_scr_path, rec_id))
    conn.commit()
    conn.close()

    return jsonify({'success': True})

# 5. DELETE: Remove Folder from Disk & Record from SQL
@app.route('/api/recordings/<int:rec_id>', methods=['DELETE'])
def delete_recording(rec_id):
    conn = get_db_connection()
    record = conn.execute('SELECT folder_name FROM recordings WHERE id = ?', (rec_id,)).fetchone()

    if record:
        folder_path = os.path.join(RECORDINGS_DIR, record['folder_name'])
        if os.path.exists(folder_path):
            shutil.rmtree(folder_path)
        
        conn.execute('DELETE FROM recordings WHERE id = ?', (rec_id,))
        conn.commit()

    conn.close()
    return jsonify({'success': True})

@app.route('/api/open-folder/<path:folder_name>', methods=['GET'])
def open_folder(folder_name):
    base = os.path.abspath(RECORDINGS_DIR)
    target = os.path.abspath(os.path.join(RECORDINGS_DIR, folder_name))
    if os.path.commonpath([base, target]) != base:
        return jsonify({'success': False, 'error': 'Invalid folder path'}), 400

    if not os.path.isdir(target):
        return jsonify({'success': False, 'error': 'Folder not found'}), 404

    try:
        if sys.platform.startswith('darwin'):
            subprocess.Popen(['open', target])
        elif os.name == 'nt':
            os.startfile(target)
        else:
            subprocess.Popen(['xdg-open', target])
        return jsonify({'success': True, 'folder_path': target})
    except Exception as exc:
        return jsonify({'success': False, 'error': str(exc)}), 500

@app.route('/api/groq-keys', methods=['GET'])
def list_groq_keys():
    conn = get_db_connection()
    rows = conn.execute('SELECT id, name, api_key, created_at FROM groq_keys ORDER BY created_at DESC').fetchall()
    conn.close()
    return jsonify([dict(row) for row in rows])

@app.route('/api/groq-keys', methods=['POST'])
def create_groq_key():
    data = request.get_json() or {}
    api_key = str(data.get('api_key', '')).strip()
    if not api_key:
        return jsonify({'success': False, 'error': 'API key is required'}), 400

    conn = get_db_connection()
    name = get_next_groq_key_name(conn)
    try:
        conn.execute('INSERT INTO groq_keys (name, api_key) VALUES (?, ?)', (name, api_key))
        conn.commit()
        new_id = conn.execute('SELECT last_insert_rowid() AS id').fetchone()['id']
    except sqlite3.IntegrityError:
        conn.close()
        return jsonify({'success': False, 'error': 'Key could not be saved'}), 400
    conn.close()
    return jsonify({'success': True, 'id': new_id, 'name': name})

@app.route('/api/groq-keys/<int:key_id>', methods=['PUT'])
def update_groq_key(key_id):
    data = request.get_json() or {}
    api_key = str(data.get('api_key', '')).strip()
    if not api_key:
        return jsonify({'success': False, 'error': 'API key is required'}), 400

    conn = get_db_connection()
    try:
        conn.execute('UPDATE groq_keys SET api_key = ? WHERE id = ?', (api_key, key_id))
        conn.commit()
    except sqlite3.IntegrityError:
        conn.close()
        return jsonify({'success': False, 'error': 'Key could not be updated'}), 400
    conn.close()
    return jsonify({'success': True})

@app.route('/api/groq-keys/<int:key_id>', methods=['DELETE'])
def delete_groq_key(key_id):
    conn = get_db_connection()
    conn.execute('DELETE FROM groq_keys WHERE id = ?', (key_id,))
    conn.commit()
    conn.close()
    return jsonify({'success': True})

@app.route('/api/groq/generate', methods=['POST'])
def generate_groq_text():
    print('[Groq] Generation request received', flush=True)
    data = request.get_json(silent=True)
    print(f'[Groq] Payload type: {type(data).__name__}', flush=True)
    if not isinstance(data, dict):
        print('[Groq] Invalid JSON payload', flush=True)
        return jsonify({'success': False, 'error': 'JSON payload must be an object'}), 400

    prompt = str(data.get('prompt', '')).strip()
    key_id = data.get('key_id')
    print(f'[Groq] Prompt length: {len(prompt)}, key_id: {key_id}', flush=True)
    if not prompt:
        print('[Groq] Rejected: prompt is empty', flush=True)
        return jsonify({'success': False, 'error': 'Prompt text is required'}), 400
    if not key_id:
        print('[Groq] Rejected: no key selected', flush=True)
        return jsonify({'success': False, 'error': 'Choose a Groq key'}), 400

    conn = get_db_connection()
    row = conn.execute('SELECT id, name, api_key FROM groq_keys WHERE id = ?', (key_id,)).fetchone()
    conn.close()
    if not row:
        print(f'[Groq] Rejected: key not found for key_id={key_id}', flush=True)
        return jsonify({'success': False, 'error': 'Groq key not found'}), 404

    try:
        print(f'[Groq] Sending request with key name: {row["name"]}', flush=True)
        payload = {
            'model': 'openai/gpt-oss-20b',
            'messages': [{'role': 'user', 'content': prompt}],
            'temperature': 0.7,
            'max_tokens': 500
        }
        req = urllib.request.Request(
            'https://api.groq.com/openai/v1/chat/completions',
            data=json.dumps(payload).encode('utf-8'),
            headers={
                'Authorization': f'Bearer {row["api_key"]}',
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'User-Agent': 'groq-recorder/1.0'
            },
            method='POST'
        )
        with urllib.request.urlopen(req, timeout=30) as response:
            print(f'[Groq] Response status: {response.status}', flush=True)
            body = response.read().decode('utf-8')
            print(f'[Groq] Response body: {body[:1000]}', flush=True)
            result = json.loads(body)
        reply = result['choices'][0]['message']['content'].strip()
        print(f'[Groq] Generation succeeded, reply length: {len(reply)}', flush=True)
        return jsonify({'success': True, 'text': reply})
    except urllib.error.HTTPError as exc:
        err = exc.read().decode('utf-8', errors='ignore')
        print(f'[Groq] HTTP error {exc.code}: {err[:1000]}', flush=True)
        print(f'[Groq] Response headers: {dict(exc.headers)}', flush=True)
        return jsonify({'success': False, 'error': 'Groq request failed: ' + err[:500]}), exc.code
    except urllib.error.URLError as exc:
        print(f'[Groq] URL/network error: {exc}', flush=True)
        return jsonify({'success': False, 'error': str(exc)}), 502
    except Exception as exc:
        print(f'[Groq] Unexpected error: {type(exc).__name__}: {exc}', flush=True)
        return jsonify({'success': False, 'error': str(exc)}), 500

# Serve Recorded Video Files
@app.route('/recordings/<path:filename>')
def serve_video(filename):
    return send_from_directory(RECORDINGS_DIR, filename)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)